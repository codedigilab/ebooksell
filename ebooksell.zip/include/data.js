const whathomewedo  = [
    {
        number: '01',
        subtitle: 'Work Process',
        title:'Best Pool Of Designers',
        details:'We have a team of skilled professionals who incorporate their creative thinking into corporate web.',
        link:'#',
    },
    {
        number: '02',
        subtitle: 'Work Process',
        title:'Comprehensive Solutions',
        details:'Our designers understand your business requirements and value propositions to the core to offer',
        link:'#',
    },
    {
        number: '03',
        subtitle: 'Work Process',
        title:'100% Satisfaction ',
        details:'With Tight quality control, right pricing, excellent accessibility and support, and timely delivery',
        link:'#',
        
    },
    {
        number: '04',
        subtitle: 'Work Process',
        title:'Deployment Support',
        details:'Our work does not end at designing your corporate website that reflects your brand. We support real-time',
        link:'#',
    },
    
    {
        number: '05',
        subtitle: 'Work Process',
        title:'24x7 Assistance',
        details:'Whatever query you have regarding your corporate website, before, after, or during the designing process.',
        link:'#',
    },
    {
        number: '06',
        subtitle: 'Work Process',
        title:'Flexible Hiring',
        details:'You can avail the services of our corporate web designers as per your requirements. You can hire part-time.',
        link:'#',
    }
]
