var elem = document.querySelector('.m-p-g');

document.addEventListener('DOMContentLoaded', function () {
    var gallery = new MaterialPhotoGallery(elem);
});